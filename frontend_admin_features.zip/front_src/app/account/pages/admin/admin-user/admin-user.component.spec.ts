import { ComponentFixture, TestBed } from '@angular/core/testing'

import { AdminUserComponent } from './admin-user.page'

describe('AdminUserComponent', () => {
    let component: AdminUserComponent
    let fixture: ComponentFixture<AdminUserComponent>

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            imports: [AdminUserComponent],
        }).compileComponents()

        fixture = TestBed.createComponent(AdminUserComponent)
        component = fixture.componentInstance
        fixture.detectChanges()
    })

    it('should create', () => {
        expect(component).toBeTruthy()
    })
})
