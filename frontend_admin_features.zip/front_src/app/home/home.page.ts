import { Component } from '@angular/core'

@Component({
    selector: 'app-home',
    standalone: true,
    templateUrl: './home.page.html',
})
export class HomeComponent {}
