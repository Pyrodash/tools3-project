import { Component } from '@angular/core'

@Component({
    standalone: true,
    templateUrl: './notfound.page.html',
})
export class NotFoundComponent {}
